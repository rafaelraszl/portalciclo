<?php
echo '
[
	{ "thumb": "json/images/3_m.jpg", "image": "json/images/3.jpg" },
	{ "thumb": "json/images/4_m.jpg", "image": "json/images/4.jpg" },
	{ "thumb": "json/images/5_m.jpg", "image": "json/images/5.jpg" },
	{ "thumb": "json/images/1_m.jpg", "image": "json/images/2.jpg" },
	{ "thumb": "json/images/1_m.jpg", "image": "json/images/1.jpg" }
]
';

?>
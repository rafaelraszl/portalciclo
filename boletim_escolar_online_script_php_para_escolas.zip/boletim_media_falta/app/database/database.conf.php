<?php
# Configura��o dos bancos de dados suportados no PDO
$databases = array( 
	# MYSQL
	'default' => array
	(
		'driver'=>'mysql',
		'host'=>'localhost',
		'port'=>3306,
		'dbname'=>'aluno',
		'user'=>'root',
		'password'=>'root'
	)
);

/* end file */

var baseUri;
baseUri = $('base').attr('href').replace('/app/','');

